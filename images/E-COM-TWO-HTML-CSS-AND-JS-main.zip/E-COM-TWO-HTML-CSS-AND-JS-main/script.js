document.addEventListener("DOMContentLoaded", function() {
    // Initialize cart from local storage or empty array
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    const cartCountElement = document.getElementById("cart-count");

    // Update cart count on all pages
    function updateCartCount() {
        if (cartCountElement) {
            cartCountElement.textContent = cart.reduce((total, item) => total + item.quantity, 0);
        }
    }

    // Save cart to local storage
    function saveCart() {
        localStorage.setItem("cart", JSON.stringify(cart));
        updateCartCount();
    }

    // Add to cart functionality
    const addToCartButtons = document.querySelectorAll(".add-to-cart");
    addToCartButtons.forEach(button => {
        button.addEventListener("click", function() {
            const productId = button.getAttribute("data-product-id");
            const productName = button.getAttribute("data-name");
            const productPrice = parseFloat(button.getAttribute("data-price"));

            const existingItem = cart.find(item => item.id === productId);
            if (existingItem) {
                existingItem.quantity++;
            } else {
                cart.push({
                    id: productId,
                    name: productName,
                    price: productPrice,
                    quantity: 1,
                    image: `images/product${productId}.jpg`
                });
            }

            saveCart();
            alert(`${productName} added to cart!`);
        });
    });

    // Cart page functionality
    if (document.getElementById("cart-items")) {
        const cartItemsContainer = document.getElementById("cart-items");
        const cartTotalElement = document.getElementById("cart-total");

        function renderCart() {
            cartItemsContainer.innerHTML = "";
            let total = 0;

            cart.forEach((item, index) => {
                total += item.price * item.quantity;
                const cartItem = document.createElement("div");
                cartItem.classList.add("cart-item");
                cartItem.innerHTML = `
                    <img src="${item.image}" alt="${item.name}">
                    <div class="cart-item-details">
                        <h3>${item.name}</h3>
                        <p>$${item.price.toFixed(2)}</p>
                    </div>
                    <div class="cart-item-quantity">
                        <button class="decrease" data-index="${index}">-</button>
                        <span>${item.quantity}</span>
                        <button class="increase" data-index="${index}">+</button>
                    </div>
                `;
                cartItemsContainer.appendChild(cartItem);
            });

            cartTotalElement.textContent = total.toFixed(2);

            document.querySelectorAll(".decrease").forEach(button => {
                button.addEventListener("click", function() {
                    const index = button.getAttribute("data-index");
                    if (cart[index].quantity > 1) {
                        cart[index].quantity--;
                    } else {
                        cart.splice(index, 1);
                    }
                    saveCart();
                    renderCart();
                });
            });

            document.querySelectorAll(".increase").forEach(button => {
                button.addEventListener("click", function() {
                    const index = button.getAttribute("data-index");
                    cart[index].quantity++;
                    saveCart();
                    renderCart();
                });
            });
        }

        renderCart();
    }

    // Contact form submission (placeholder)
    const contactForm = document.querySelector(".contact-form");
    if (contactForm) {
        contactForm.addEventListener("submit", function(e) {
            e.preventDefault();
            const name = contactForm.querySelector("input[type='text']").value;
            const email = contactForm.querySelector("input[type='email']").value;
            const message = contactForm.querySelector("textarea").value;
            console.log(`Contact Form Submitted: Name: ${name}, Email: ${email}, Message: ${message}`);
            alert("Thank you for your message! We’ll get back to you soon.");
            contactForm.reset();
        });
    }

    // Search functionality (placeholder)
    const searchButton = document.querySelector(".search-bar button");
    if (searchButton) {
        searchButton.addEventListener("click", function() {
            const searchInput = document.querySelector(".search-bar input").value;
            console.log(`Searching for: ${searchInput}`);
        });
    }

    // Initial cart count update
    updateCartCount();

    // Menu toggle functionality
    const menuToggle = document.querySelector('.menu-toggle');
    const navLinks = document.querySelector('.nav-links');
    const dropdowns = document.querySelectorAll('.dropdown');

    menuToggle.addEventListener('click', function() {
        navLinks.classList.toggle('active');
    });

    dropdowns.forEach(dropdown => {
        dropdown.addEventListener('click', function(e) {
            if (window.innerWidth <= 768) {
                e.preventDefault();
                this.classList.toggle('active');
            }
        });
    });

    // Close menu when clicking outside
    document.addEventListener('click', function(e) {
        if (!navLinks.contains(e.target) && !menuToggle.contains(e.target)) {
            navLinks.classList.remove('active');
            dropdowns.forEach(dropdown => dropdown.classList.remove('active'));
        }
    });
});